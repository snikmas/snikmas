import Link from 'next/link'
import { directions } from './data'

export function DirectionSwitcher({ current }: { current: string }) {
  return (
    <nav
      aria-label="Design directions"
      className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2"
    >
      <div className="flex items-center gap-1 border border-border bg-card/95 px-2 py-1.5 font-mono text-xs backdrop-blur">
        <Link
          href="/"
          className="px-2 py-1 text-muted-foreground transition-colors hover:text-foreground"
        >
          index
        </Link>
        <span aria-hidden="true" className="text-border">
          /
        </span>
        {directions.map((d) => (
          <Link
            key={d.id}
            href={d.href}
            aria-current={current === d.href ? 'page' : undefined}
            className={
              current === d.href
                ? 'bg-accent px-2 py-1 text-accent-foreground'
                : 'px-2 py-1 text-muted-foreground transition-colors hover:text-foreground'
            }
          >
            {d.id}
          </Link>
        ))}
      </div>
    </nav>
  )
}
