export const owner = {
  name: 'Mary',
  handle: 'snikmas',
  role: 'Computer science student · Backend & LLM tooling',
  location: 'Hangzhou, China',
  tagline:
    'I build backend tools, poke at large language models, and write about what breaks along the way.',
  email: 'hello@snikmas.dev',
  github: 'https://github.com/snikmas',
  now: 'Building an LLM eval harness · Reading “The Idea Factory”',
}

export const projects = [
  {
    slug: 'relay',
    name: 'relay',
    year: '2026',
    kind: 'Backend infrastructure',
    stack: ['Go', 'PostgreSQL', 'Redis'],
    summary:
      'A small, honest task queue. At-least-once delivery, dead-letter handling, and a dashboard that tells the truth about backpressure.',
    detail:
      'Built after a course project queue silently dropped jobs during finals week. Handles ~4k jobs/min on a single node.',
  },
  {
    slug: 'chalk',
    name: 'chalk',
    year: '2026',
    kind: 'LLM tooling',
    stack: ['Python', 'FastAPI', 'SQLite'],
    summary:
      'An eval harness for comparing LLM outputs across prompts, models, and temperature sweeps — with diffs a human can actually read.',
    detail:
      'Snapshot-based regression testing for prompts. Used to catch a 12% quality drop after a model version bump.',
  },
  {
    slug: 'hanzi-pipe',
    name: 'hanzi-pipe',
    year: '2025',
    kind: 'Automation',
    stack: ['Python', 'Anki', 'LLM APIs'],
    summary:
      'A pipeline that turns Mandarin words I encounter on campus into Anki cards with generated mnemonics, audio, and example sentences.',
    detail:
      'Feeds from a Telegram bot. 2,400 cards generated so far; my HSK vocabulary is grateful.',
  },
  {
    slug: 'dorm-metrics',
    name: 'dorm-metrics',
    year: '2025',
    kind: 'Backend / observability',
    stack: ['Go', 'Prometheus', 'Grafana'],
    summary:
      'Self-hosted monitoring for my dorm homelab — power cuts, Wi-Fi drops, and the exact moment the hot water dies.',
    detail:
      'Runs on a second-hand mini PC under my desk. Uptime is a lifestyle.',
  },
]

export const stack = {
  languages: ['Go', 'Python', 'TypeScript', 'SQL', 'C'],
  backend: ['PostgreSQL', 'Redis', 'FastAPI', 'gRPC', 'Docker'],
  llm: ['OpenAI / Anthropic APIs', 'eval harnesses', 'prompt pipelines', 'embeddings'],
  tools: ['Linux', 'Git', 'Prometheus', 'Neovim'],
}

export const posts = [
  {
    slug: 'queues-lie',
    title: 'Your queue is lying to you',
    date: '2026-06-14',
    tag: 'programming',
    minutes: 9,
    excerpt:
      'Every task queue promises exactly-once. None of them mean it. Notes from building relay and learning to love idempotency keys.',
  },
  {
    slug: 'evals-are-vibes',
    title: 'LLM evals are vibes with a spreadsheet',
    date: '2026-05-02',
    tag: 'ai',
    minutes: 12,
    excerpt:
      'We pretend eval scores are measurements. Mostly they are opinions with decimal points. How I try to make mine slightly less dishonest.',
  },
  {
    slug: 'canteen-determinism',
    title: 'Determinism and the campus canteen',
    date: '2026-03-21',
    tag: 'student life',
    minutes: 6,
    excerpt:
      'The 11:40 rush at the second canteen is a distributed systems problem. So is choosing between rice window three and rice window five.',
  },
  {
    slug: 'idea-factory-notes',
    title: 'Reading “The Idea Factory” in a dorm room',
    date: '2026-02-08',
    tag: 'books',
    minutes: 8,
    excerpt:
      'Bell Labs gave people hallways and time. Notes on what a CS student can steal from 1950s research culture.',
  },
  {
    slug: 'mandarin-stack-traces',
    title: 'Debugging in my third language',
    date: '2025-12-19',
    tag: 'china',
    minutes: 7,
    excerpt:
      'What it is like to read stack traces in English, lectures in Mandarin, and think in neither by the end of the day.',
  },
]

export const directions = [
  {
    id: '01',
    href: '/ledger',
    theme: 'dir-ledger',
    name: 'The Ledger',
    swatch: 'oklch(0.76 0.115 78)',
    voice: 'Editorial & typographic',
    blurb:
      'Oversized serif headlines, ruled sections, and a numbered index of work. Reads like the front page of a very personal broadsheet.',
  },
  {
    id: '02',
    href: '/journal',
    theme: 'dir-journal',
    name: 'Field Notes',
    swatch: 'oklch(0.75 0.1 135)',
    voice: 'Personal & annotated',
    blurb:
      'A fixed margin of metadata beside a continuous journal. Projects and essays flow as dated entries with notes in the margin.',
  },
  {
    id: '03',
    href: '/index-grid',
    theme: 'dir-index',
    name: 'The Index',
    swatch: 'oklch(0.68 0.19 40)',
    voice: 'Structural & recruiter-fast',
    blurb:
      'A hard-ruled grid of cells: facts, projects, stack, and writing as scannable records. Everything a recruiter needs above the fold.',
  },
]
