import Link from 'next/link'
import { directions, owner } from '@/components/site/data'

export default function DirectionsIndex() {
  return (
    <main className="mx-auto flex min-h-svh w-full max-w-4xl flex-col justify-center px-6 py-16">
      <header className="mb-14">
        <p className="mb-3 font-mono text-xs uppercase tracking-widest text-muted-foreground">
          snikmas.dev — design exploration
        </p>
        <h1 className="text-3xl font-medium text-balance md:text-4xl">
          Three directions for {owner.name}&apos;s portfolio &amp; journal
        </h1>
        <p className="mt-4 max-w-xl leading-relaxed text-muted-foreground">
          Same content, three genuinely different systems — different layout
          logic, typography, and personality. Pick one and it becomes the site.
        </p>
      </header>

      <div className="flex flex-col border-t border-border">
        {directions.map((d) => (
          <Link
            key={d.id}
            href={d.href}
            className={`${d.theme} group border-b border-border py-8 transition-colors hover:bg-muted/60`}
          >
            <div className="flex flex-col gap-4 md:flex-row md:items-baseline md:gap-8">
              <span className="font-mono text-xs text-muted-foreground">
                {d.id}
              </span>
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <span
                    aria-hidden="true"
                    className="size-3 shrink-0"
                    style={{ backgroundColor: d.swatch }}
                  />
                  <h2 className="text-2xl font-medium group-hover:underline group-hover:underline-offset-4">
                    {d.name}
                  </h2>
                </div>
                <p className="mt-2 max-w-lg leading-relaxed text-muted-foreground">
                  {d.blurb}
                </p>
              </div>
              <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                {d.voice} →
              </span>
            </div>
          </Link>
        ))}
      </div>

      <footer className="mt-14 font-mono text-xs text-muted-foreground">
        {owner.handle} · {owner.location}
      </footer>
    </main>
  )
}
