import type { Metadata } from 'next'
import { DirectionSwitcher } from '@/components/site/direction-switcher'
import { owner, posts, projects, stack } from '@/components/site/data'

export const metadata: Metadata = {
  title: 'Field Notes — snikmas',
  description: 'Direction 02: a personal, annotated journal layout for Mary (snikmas).',
}

function MarginLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="block font-mono text-xs uppercase tracking-widest text-accent lg:pt-1.5 lg:text-right">
      {children}
    </span>
  )
}

function Entry({
  label,
  children,
  id,
}: {
  label: React.ReactNode
  children: React.ReactNode
  id?: string
}) {
  return (
    <section
      id={id}
      className="grid gap-3 border-t border-border py-10 lg:grid-cols-[10rem_1fr] lg:gap-10"
    >
      <MarginLabel>{label}</MarginLabel>
      <div>{children}</div>
    </section>
  )
}

const navLinks = [
  ['#intro', 'intro'],
  ['#projects', 'projects'],
  ['#stack', 'stack'],
  ['#writing', 'writing'],
  ['#contact', 'contact'],
] as const

export default function JournalPage() {
  return (
    <div className="dir-journal min-h-svh bg-background text-foreground">
      {/* Sticky top header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex w-full max-w-5xl flex-wrap items-baseline justify-between gap-x-8 gap-y-2 px-6 py-4 lg:px-10">
          <a href="#intro" className="flex items-baseline gap-2">
            <span className="text-lg font-medium">{owner.name}</span>
            <span className="text-sm text-muted-foreground">/ {owner.handle}</span>
          </a>
          <nav aria-label="Sections" className="flex flex-wrap gap-x-5 gap-y-1 font-mono text-xs">
            {navLinks.map(([href, label]) => (
              <a
                key={href}
                href={href}
                className="text-muted-foreground transition-colors hover:text-accent"
              >
                {label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl px-6 pb-32 lg:px-10">
        {/* Intro: short bio + facts */}
        <section id="intro" className="py-14 lg:py-20">
          <p className="font-mono text-xs uppercase tracking-widest text-accent">
            introduction
          </p>
          <h1 className="mt-4 text-3xl font-medium leading-snug text-balance md:text-4xl">
            Hi, I&apos;m {owner.name} — {owner.handle} online.
          </h1>
          <p className="mt-5 max-w-2xl leading-relaxed text-muted-foreground">
            I&apos;m a computer science student in Hangzhou. {owner.tagline}
            {' '}In between, I write — about programming, AI, books, and what it&apos;s
            like to study and live in China.
          </p>

          <dl className="mt-10 grid max-w-2xl gap-x-8 gap-y-4 font-mono text-xs leading-relaxed sm:grid-cols-2">
            <div>
              <dt className="text-accent">location</dt>
              <dd className="text-muted-foreground">{owner.location} · UTC+8</dd>
            </div>
            <div>
              <dt className="text-accent">studying</dt>
              <dd className="text-muted-foreground">computer science</dd>
            </div>
            <div>
              <dt className="text-accent">now</dt>
              <dd className="text-muted-foreground">{owner.now}</dd>
            </div>
            <div>
              <dt className="text-accent">open to</dt>
              <dd className="text-muted-foreground">backend / LLM internships</dd>
            </div>
          </dl>
        </section>

        <Entry label="projects" id="projects">
          <div className="flex flex-col gap-10">
            {projects.map((p) => (
              <article key={p.slug} className="group">
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                  <h2 className="text-xl font-medium">
                    <a href={`#${p.slug}`} className="transition-colors group-hover:text-accent">
                      {p.name}
                    </a>
                  </h2>
                  <span className="font-mono text-xs text-muted-foreground">
                    {p.year} · {p.kind.toLowerCase()} · {p.stack.join(', ')}
                  </span>
                </div>
                <p className="mt-2 max-w-2xl leading-relaxed">{p.summary}</p>
                <p className="mt-2 max-w-2xl border-l-2 border-accent pl-4 text-sm leading-relaxed text-muted-foreground">
                  {p.detail}
                </p>
              </article>
            ))}
          </div>
        </Entry>

        <Entry label="stack" id="stack">
          <div className="grid max-w-2xl gap-x-8 gap-y-5 sm:grid-cols-2">
            {Object.entries({
              languages: stack.languages,
              'backend & data': stack.backend,
              'llm work': stack.llm,
              tooling: stack.tools,
            }).map(([label, items]) => (
              <div key={label}>
                <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  {label}
                </h3>
                <p className="mt-1.5 leading-relaxed">{items.join(', ')}</p>
              </div>
            ))}
          </div>
        </Entry>

        <Entry label="writing" id="writing">
          <div className="flex flex-col gap-8">
            {posts.map((post) => (
              <article key={post.slug} className="group max-w-2xl">
                <p className="font-mono text-xs text-muted-foreground">
                  <time dateTime={post.date}>{post.date}</time> · {post.tag} ·{' '}
                  {post.minutes} min
                </p>
                <h2 className="mt-1 text-xl font-medium text-balance">
                  <a href={`#${post.slug}`} className="transition-colors group-hover:text-accent">
                    {post.title}
                  </a>
                </h2>
                <p className="mt-1.5 leading-relaxed text-muted-foreground">
                  {post.excerpt}
                </p>
              </article>
            ))}
          </div>
        </Entry>

        <Entry label="contact" id="contact">
          <p className="max-w-2xl text-xl leading-relaxed text-balance">
            The best conversations start as emails about queues, models, or
            books. If you&apos;re hiring, collaborating, or just read something
            here you disagreed with —{' '}
            <a
              href={`mailto:${owner.email}`}
              className="text-accent underline decoration-1 underline-offset-4 transition-opacity hover:opacity-80"
            >
              say hello
            </a>
            .
          </p>
          <div className="mt-6 flex flex-wrap gap-6 font-mono text-xs text-muted-foreground">
            <a href={`mailto:${owner.email}`} className="transition-colors hover:text-accent">
              {owner.email}
            </a>
            <a href={owner.github} className="transition-colors hover:text-accent">
              github/{owner.handle}
            </a>
          </div>
        </Entry>
      </main>
      <DirectionSwitcher current="/journal" />
    </div>
  )
}
