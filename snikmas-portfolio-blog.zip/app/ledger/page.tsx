import type { Metadata } from 'next'
import { DirectionSwitcher } from '@/components/site/direction-switcher'
import { owner, posts, projects, stack } from '@/components/site/data'

export const metadata: Metadata = {
  title: 'The Ledger — snikmas',
  description: 'Direction 01: an editorial, typographic portfolio for Mary (snikmas).',
}

function RuledHeading({ num, title }: { num: string; title: string }) {
  return (
    <div className="flex items-baseline justify-between border-t border-foreground/60 pt-3">
      <h2 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
        {title}
      </h2>
      <span className="font-mono text-xs text-accent">{num}</span>
    </div>
  )
}

export default function LedgerPage() {
  return (
    <div className="dir-ledger min-h-svh bg-background font-serif text-foreground">
      <main className="mx-auto w-full max-w-5xl px-6 pb-32 pt-8 md:px-10">
        {/* Masthead */}
        <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-border pb-4 font-mono text-xs text-muted-foreground">
          <span>{owner.handle}.dev</span>
          <span className="hidden md:inline">{owner.location} · UTC+8</span>
          <nav aria-label="Sections" className="flex gap-5">
            <a href="#work" className="transition-colors hover:text-accent">work</a>
            <a href="#stack" className="transition-colors hover:text-accent">stack</a>
            <a href="#writing" className="transition-colors hover:text-accent">writing</a>
            <a href="#contact" className="transition-colors hover:text-accent">contact</a>
          </nav>
        </header>

        {/* Hero */}
        <section className="py-16 md:py-24">
          <p className="mb-6 font-mono text-xs uppercase tracking-[0.25em] text-accent">
            A developer&apos;s ledger — est. Hangzhou
          </p>
          <h1 className="text-6xl leading-[0.95] tracking-tight text-balance md:text-8xl lg:text-9xl">
            Mary,
            <br />
            <em className="text-accent">or snikmas.</em>
          </h1>
          <div className="mt-10 grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
            <p className="max-w-xl text-xl leading-relaxed text-pretty md:text-2xl">
              {owner.tagline} Computer science student in China; most at home
              somewhere between a Postgres query plan and a half-finished essay.
            </p>
            <dl className="font-mono text-xs leading-relaxed text-muted-foreground">
              <div className="flex gap-4">
                <dt className="w-14 text-accent">now</dt>
                <dd>LLM eval harness</dd>
              </div>
              <div className="flex gap-4">
                <dt className="w-14 text-accent">reading</dt>
                <dd>The Idea Factory</dd>
              </div>
              <div className="flex gap-4">
                <dt className="w-14 text-accent">status</dt>
                <dd>open to internships</dd>
              </div>
            </dl>
          </div>
        </section>

        {/* Selected work */}
        <section id="work" aria-label="Selected work" className="mb-20">
          <RuledHeading num="01" title="Selected work" />
          <ul>
            {projects.map((p, i) => (
              <li key={p.slug} className="group border-b border-border">
                <a
                  href={`#${p.slug}`}
                  className="grid gap-2 py-7 md:grid-cols-[auto_1fr_auto] md:items-baseline md:gap-8"
                >
                  <span className="font-mono text-xs text-muted-foreground">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <div>
                    <h3 className="text-3xl tracking-tight transition-colors group-hover:text-accent md:text-4xl">
                      {p.name}
                      <em className="ml-3 text-lg text-muted-foreground md:text-xl">
                        {p.kind.toLowerCase()}
                      </em>
                    </h3>
                    <p className="mt-2 max-w-2xl leading-relaxed text-muted-foreground">
                      {p.summary}
                    </p>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground">
                    {p.year} · {p.stack.join(' / ')}
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </section>

        {/* Stack */}
        <section id="stack" aria-label="Technology stack" className="mb-20">
          <RuledHeading num="02" title="Stack" />
          <dl className="mt-6 grid gap-x-10 gap-y-6 md:grid-cols-2">
            {Object.entries({
              Languages: stack.languages,
              'Backend & data': stack.backend,
              'LLM work': stack.llm,
              Tooling: stack.tools,
            }).map(([label, items]) => (
              <div key={label} className="flex flex-col gap-1">
                <dt className="text-lg italic text-accent">{label}</dt>
                <dd className="font-mono text-sm leading-relaxed text-muted-foreground">
                  {items.join(' · ')}
                </dd>
              </div>
            ))}
          </dl>
        </section>

        {/* Writing */}
        <section id="writing" aria-label="Latest writing" className="mb-20">
          <RuledHeading num="03" title="Latest writing" />
          <ul>
            {posts.slice(0, 4).map((post) => (
              <li key={post.slug} className="group border-b border-border">
                <a
                  href={`#${post.slug}`}
                  className="grid gap-1 py-6 md:grid-cols-[auto_1fr_auto] md:items-baseline md:gap-8"
                >
                  <time
                    dateTime={post.date}
                    className="font-mono text-xs text-muted-foreground"
                  >
                    {post.date}
                  </time>
                  <div>
                    <h3 className="text-2xl tracking-tight text-balance transition-colors group-hover:text-accent">
                      {post.title}
                    </h3>
                    <p className="mt-1 max-w-2xl leading-relaxed text-muted-foreground">
                      {post.excerpt}
                    </p>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground">
                    {post.tag} · {post.minutes} min
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </section>

        {/* Contact */}
        <section id="contact" aria-label="Contact">
          <RuledHeading num="04" title="Contact" />
          <div className="py-14">
            <p className="text-4xl leading-tight tracking-tight text-balance md:text-6xl">
              Building something with queues, models, or words?{' '}
              <a
                href={`mailto:${owner.email}`}
                className="italic text-accent underline decoration-1 underline-offset-8 transition-opacity hover:opacity-80"
              >
                Write to me.
              </a>
            </p>
            <div className="mt-10 flex flex-wrap gap-6 font-mono text-xs text-muted-foreground">
              <a href={`mailto:${owner.email}`} className="transition-colors hover:text-accent">
                {owner.email}
              </a>
              <a href={owner.github} className="transition-colors hover:text-accent">
                github/{owner.handle}
              </a>
              <span>{owner.location}</span>
            </div>
          </div>
        </section>
      </main>
      <DirectionSwitcher current="/ledger" />
    </div>
  )
}
