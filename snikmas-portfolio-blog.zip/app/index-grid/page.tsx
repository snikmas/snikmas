import type { Metadata } from 'next'
import { DirectionSwitcher } from '@/components/site/direction-switcher'
import { owner, posts, projects, stack } from '@/components/site/data'

export const metadata: Metadata = {
  title: 'The Index — snikmas',
  description: 'Direction 03: a hard-ruled structural grid portfolio for Mary (snikmas).',
}

function CellLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-4 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
      {children}
    </p>
  )
}

export default function IndexGridPage() {
  return (
    <div className="dir-index min-h-svh bg-background font-grotesk text-foreground">
      <main className="mx-auto w-full max-w-6xl px-4 pb-32 pt-6 md:px-8">
        {/* Header bar */}
        <header className="grid border border-border md:grid-cols-[1fr_auto_auto]">
          <div className="flex items-center gap-3 px-4 py-3">
            <span aria-hidden="true" className="size-2 bg-accent" />
            <span className="text-sm font-medium uppercase tracking-wide">
              {owner.handle} — record of work
            </span>
          </div>
          <div className="hidden items-center border-l border-border px-4 py-3 font-mono text-xs text-muted-foreground md:flex">
            {owner.location} / UTC+8
          </div>
          <nav
            aria-label="Sections"
            className="flex items-center gap-4 border-t border-border px-4 py-3 font-mono text-xs md:border-l md:border-t-0"
          >
            <a href="#projects" className="text-muted-foreground transition-colors hover:text-accent">PRJ</a>
            <a href="#stack" className="text-muted-foreground transition-colors hover:text-accent">STK</a>
            <a href="#writing" className="text-muted-foreground transition-colors hover:text-accent">WRT</a>
            <a href="#contact" className="text-muted-foreground transition-colors hover:text-accent">CNT</a>
          </nav>
        </header>

        {/* Hero row: intro + facts */}
        <section
          aria-label="Introduction"
          className="grid border-x border-b border-border lg:grid-cols-[2fr_1fr]"
        >
          <div className="px-4 py-10 md:px-8 md:py-14">
            <CellLabel>00 / identity</CellLabel>
            <h1 className="text-4xl font-medium uppercase leading-[1.02] tracking-tight text-balance md:text-6xl">
              Mary builds
              <br />
              backend systems
              <br />
              <span className="text-accent">&amp; LLM tooling.</span>
            </h1>
            <p className="mt-6 max-w-lg leading-relaxed text-muted-foreground">
              Computer science student in China. {owner.tagline} Also writes —
              essays on programming, AI, books, and student life live further
              down this page.
            </p>
          </div>
          <dl className="grid grid-cols-2 border-t border-border lg:grid-cols-1 lg:border-l lg:border-t-0">
            {[
              ['degree', 'B.Eng. Computer Science'],
              ['focus', 'Backend · LLMs · Automation'],
              ['status', 'Open to internships'],
              ['languages', 'EN · RU · 中文 (HSK4)'],
            ].map(([dt, dd], i) => (
              <div
                key={dt}
                className={`px-4 py-4 md:px-6 ${i > 0 ? 'border-t border-border max-lg:[&:nth-child(2)]:border-t-0' : ''} max-lg:odd:border-r max-lg:odd:border-border`}
              >
                <dt className="font-mono text-[11px] uppercase tracking-[0.2em] text-accent">
                  {dt}
                </dt>
                <dd className="mt-1 text-sm">{dd}</dd>
              </div>
            ))}
          </dl>
        </section>

        {/* Projects table */}
        <section id="projects" aria-label="Projects" className="border-x border-b border-border">
          <div className="border-b border-border px-4 py-3 md:px-8">
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
              01 / projects — {projects.length} records
            </p>
          </div>
          {projects.map((p, i) => (
            <a
              key={p.slug}
              href={`#${p.slug}`}
              className="group grid border-b border-border last:border-b-0 md:grid-cols-[4rem_1fr_2fr_auto] md:items-center"
            >
              <span className="px-4 pt-4 font-mono text-xs text-muted-foreground md:py-5 md:pt-5">
                {String(i + 1).padStart(3, '0')}
              </span>
              <h2 className="px-4 pt-1 text-2xl font-medium uppercase tracking-tight transition-colors group-hover:text-accent md:py-5 md:pt-5 md:text-3xl">
                {p.name}
              </h2>
              <p className="px-4 pt-2 text-sm leading-relaxed text-muted-foreground md:py-5 md:pt-5">
                {p.summary}
              </p>
              <span className="px-4 pb-4 pt-2 font-mono text-xs text-muted-foreground md:py-5 md:text-right">
                {p.year}
                <br className="hidden md:block" />
                <span className="md:text-accent"> {p.stack.join(' · ')}</span>
              </span>
            </a>
          ))}
        </section>

        {/* Stack + latest writing side by side */}
        <div className="grid border-x border-b border-border lg:grid-cols-2">
          <section id="stack" aria-label="Technology stack" className="px-4 py-8 md:px-8">
            <CellLabel>02 / stack</CellLabel>
            <dl className="flex flex-col gap-5">
              {Object.entries({
                languages: stack.languages,
                'backend & data': stack.backend,
                'llm work': stack.llm,
                tooling: stack.tools,
              }).map(([label, items]) => (
                <div key={label} className="grid gap-1 sm:grid-cols-[9rem_1fr]">
                  <dt className="font-mono text-xs uppercase tracking-wider text-accent">
                    {label}
                  </dt>
                  <dd className="flex flex-wrap gap-x-1 gap-y-2">
                    {items.map((item) => (
                      <span
                        key={item}
                        className="border border-border px-2 py-0.5 font-mono text-xs text-muted-foreground"
                      >
                        {item}
                      </span>
                    ))}
                  </dd>
                </div>
              ))}
            </dl>
          </section>

          <section
            id="writing"
            aria-label="Latest writing"
            className="border-t border-border px-4 py-8 md:px-8 lg:border-l lg:border-t-0"
          >
            <CellLabel>03 / latest writing</CellLabel>
            <ul className="flex flex-col">
              {posts.slice(0, 5).map((post) => (
                <li key={post.slug} className="group border-t border-border first:border-t-0">
                  <a href={`#${post.slug}`} className="flex flex-col gap-1 py-4">
                    <span className="font-mono text-[11px] text-muted-foreground">
                      <time dateTime={post.date}>{post.date}</time> / {post.tag}
                    </span>
                    <span className="font-medium text-balance transition-colors group-hover:text-accent">
                      {post.title}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </section>
        </div>

        {/* Contact */}
        <section
          id="contact"
          aria-label="Contact"
          className="grid border-x border-b border-border md:grid-cols-[1fr_auto]"
        >
          <div className="px-4 py-10 md:px-8">
            <CellLabel>04 / contact</CellLabel>
            <p className="text-3xl font-medium uppercase leading-tight tracking-tight text-balance md:text-5xl">
              Hiring for backend or LLM work?
              <br />
              <a
                href={`mailto:${owner.email}`}
                className="text-accent underline decoration-2 underline-offset-8 transition-opacity hover:opacity-80"
              >
                Get in touch.
              </a>
            </p>
          </div>
          <div className="flex flex-col justify-center gap-2 border-t border-border px-4 py-6 font-mono text-xs text-muted-foreground md:border-l md:border-t-0 md:px-8">
            <a href={`mailto:${owner.email}`} className="transition-colors hover:text-accent">
              {owner.email}
            </a>
            <a href={owner.github} className="transition-colors hover:text-accent">
              github/{owner.handle}
            </a>
            <span>{owner.location}</span>
          </div>
        </section>

        <footer className="flex justify-between px-1 py-3 font-mono text-[11px] text-muted-foreground">
          <span>© 2026 {owner.handle}</span>
          <span>direction 03 / the index</span>
        </footer>
      </main>
      <DirectionSwitcher current="/index-grid" />
    </div>
  )
}
